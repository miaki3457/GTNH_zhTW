# Radar Upgrade

![Aware.](item:computronics:computronics.ocParts@2)

The Radar upgrade provides the same functionality as the [radar](../block/radar.md) block and can be placed into a robot or drone with a tier 3 upgrade slot. This allows robots and drones to detect nearby entities such as players, mobs or dropped items.
