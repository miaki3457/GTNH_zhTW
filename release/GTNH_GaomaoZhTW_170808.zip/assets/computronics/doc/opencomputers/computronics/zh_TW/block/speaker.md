# Speaker

![Audiophile certified.](block:computronics:computronics.speaker)

This electroacoustic transducer may be connected to [audio cables](audio_cable.md). It will pick up any audio signal sent through the cables and convert it to sound, making it audible.
