# Drone Docking Station

![The lower part.](item:computronics:computronics.droneStation)

The Drone docking station is an item that may be placed on a Buildcraft pipe, allowing drones with the [docking upgrade](docking_upgrade.md) to dock. This allows for items to be transferred to a Buildcraft pipe network as well as charging the drone from a Kinesis Pipe.
