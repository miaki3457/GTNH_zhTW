# Digital Relay Sensor

![Single-use.](item:computronics:computronics.relaySensor)

The Digital relay sensor is used to pair a [locomotive relay](../../block/railcraft/locomotive_relay.md) with an electric locomotive from Railcraft. Devices are paired by first sneak right-clicking the relay sensor on the [locomotive relay](../../block/railcraft/locomotive_relay.md), followed by sneak left-clicking the electric locomotive to attach the relay sensor.
