# Chat Upgrade

![Just chatting with my robots.](item:computronics:computronics.ocParts@1)

The chat upgrade can be placed into robots and drones with a tier 2 upgrade slot or higher. The upgrade behaves similarly to the [chat box](../block/chatbox.md) allowing for integration with the Minecraft chat box. As with the [chat box](../block/chatbox.md), listening distance can be specified up to a maximum (which can be defined in the configs).

Possible uses could include triggering certain programs on the robot and drone by typing commands in the chat box, with the robot and drone set to look for specific chat box messages.
