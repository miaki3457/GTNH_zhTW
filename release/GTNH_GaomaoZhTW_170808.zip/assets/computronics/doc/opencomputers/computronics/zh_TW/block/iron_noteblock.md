# Iron Note Block

![Better than a Note Block.](block:computronics:computronics.ironNoteBlock)

The Iron note block is capable of playing various notes using different instruments. These instruments (such as the piano or bass drum) are defined by the Minecraft note block. The note block is capable of playing 24 notes per instrument and takes an optional volume parameter between 0 to 1.
