# Drone Docking Upgrade

![The upper part.](item:computronics:computronics.dockingUpgrade)

The Drone docking upgrade is an upgrade which allows drones to dock onto a Buildcraft pipe with a [drone docking station](drone_station.md). Docking upgrades can be placed into a drone with a tier 1 upgrade slot or higher.
