# Self-Destructing Card

![Useful and convenient.](item:computronics:computronics.ocParts@6)

The Self-destructing card allows for computers or robots to self-destruct after a specified duration (default 5 seconds). Devices are completely and irreversibly destroyed.

You can create a floppy disk called `explode` containing a program with the same name  which allows for convenient and highly configurable self-destruction. 
