# Chat Box

![Talk to me!](block:computronics:computronics.chatBox)

The chat box allows the computer to write/read messages to/from Minecraft chat. For reading or saying messages, a listening distance can be specified (default: 40 blocks). This can allow programs on the computer to be triggered from the chatbox, by reading the message contained in the `chat_message` event. 

The chat box emits a 4-tick redstone pulse upon receiving a message, for integration with various redstone control.
