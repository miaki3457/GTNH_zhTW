# Pink Flamingo

![Yep, it's real.](block:Flamingo:flamingo.flamingo)

Exploiting the serial port module's undocumented ability to poke things, it is possible to make Flamingos wiggle. Writing any value to the serial port will result in the module making the Flamingo wiggle, as if a human had poked it.
