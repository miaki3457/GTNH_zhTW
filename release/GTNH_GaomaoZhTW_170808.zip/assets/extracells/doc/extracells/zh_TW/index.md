# Extra Cells 2 Manual

![Extra Cells](item:extracells:storage.fluid@0)


## Items
* [ME Upgrade](me_upgrade.md)