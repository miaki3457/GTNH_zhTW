# ME Upgrade

![Connect to your me network](item:extracells:oc.upgrade@2)

可以將 me upgrade加進 [機器人](/%LANGUAGE%/block/robot.md) 和[無人機](/%LANGUAGE%/item/drone.md) 裡面. 這東西可以無線連接到你的me系統. Put this upgrade or a [robot](/%LANGUAGE%/block/robot.md)/[drone](/%LANGUAGE%/item/drone.md) into your ae security station to link it with your network. The ranged depents on the tier of the upgrade.


Tier 1: 0.5x access point range.
Tier 2: access point range.
Tier 3: infinity ranger, over dimensions