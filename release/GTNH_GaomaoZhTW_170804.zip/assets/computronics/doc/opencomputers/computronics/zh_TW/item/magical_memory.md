# Magical Memory

![Mnemonic Masterpieces](item:computronics:computronics.ocSpecialParts@0)

This magical device is a type of [memory](/%LANGUAGE%/item/ram1.md) that appears to store data sent to it in bytes it gathers from its surroundings, cosmic radiation, Scumm™ and off-by-one errors, making it an indefinitely powerful item. Fortunately, this artifact can neither be found nor crafted; due to budget cuts, its effects on the universe have not been tested yet and total collapse is not out of question, although experts tend to claim that this item, instead of absorbing the universe, would simply provide a lot of usable memory to a computer. 
