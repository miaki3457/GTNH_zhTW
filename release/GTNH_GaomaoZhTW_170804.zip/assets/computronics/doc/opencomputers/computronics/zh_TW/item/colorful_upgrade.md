# Colorful Upgrade

![Even prettier.](item:computronics:computronics.ocParts@7)

This Upgrade can only be put into Robots. It provides a component called `colors` which allows changing the color of the Robot case. It can be used with `robot.setLightColor` to make your Robots even more pretty than before!
