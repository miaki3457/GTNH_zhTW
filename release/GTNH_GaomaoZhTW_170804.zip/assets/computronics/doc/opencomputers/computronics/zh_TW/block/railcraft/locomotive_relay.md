# Digital Locomotive Relay

![Welcome to the future.](block:computronics:computronics.locomotiveRelay)

The Digital Locomotive relay allows computers to communicate with the Electric locomotive from Railcraft. A [digital relay sensor](../../item/railcraft/relay_sensor.md) is needed for pairing: sneak right-click to bind the [relay sensor](../../item/railcraft/relay_sensor.md) to the Locomotive relay, then sneak left-click on an electric locomotive to attach the [sensor](../../item/railcraft/relay_sensor.md) to the locomotive. Once attached, the electric locomotive can be controlled using the `locomotive_relay` component API.
