# Particle Effects Card

![Everyone wants pretty particles.](item:computronics:computronics.ocParts@3)

The Particle effects card allows computers, robots, and drones (containing a tier 2 upgrade slot or higher) to create particle effects at a specified location, as defined by the coordinates relative to the device. The particle name provided to the component API function must be a valid Minecraft particle.
