# Spoofing Card

![When you whack a card with a brick...](item:computronics:computronics.ocParts@4)

The spoofing card acts the same way as a [network card](/%LANGUAGE%/item/lanCard.md) from Open Computers, but allows players to specify the source address, effectively masking the device sending the network messages. The spoofing card requires a tier 2 card slot or higher.
