# Cassette Tape

![May contain music.](item:computronics:computronics.tape@0)

Cassette tapes are used for recording and playback of audio using the [tape drive](../block/tape_drive.md). Tapes come in varying lengths from 2 to 128 minutes, and can also be used to store other types of information (storage space is roughly the number of minutes the tape can record divided by 4, in Megabytes). Audio is recorded using the DFPWM format, as detailed in the [tape drive](../block/tape_drive.md) document. 
