# Light Board

![And Notch said, Let there be light.](item:computronics:computronics.ocParts@10)

This Board can be put into Server Racks. It provides four visual indicator lights which connected computers are able to control using the provided `light_board` component.

If you interact with the board using any type of [wrench](/%LANGUAGE%/item/wrench.md), you can change its layout. Note that this resets the color settings. 
