# Computronics Manual

This index lists all of the documented TIS-3D modules in Computronics.

## Modules
* [Colorful Module](colorful_module.md)
* [Tape Reader Module](tape_reader_module.md)
* [Self-Destructing Module](self_destructing_module.md)
